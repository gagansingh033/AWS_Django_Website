from django.apps import AppConfig


class FeedbackappConfig(AppConfig):
    name = 'feedbackapp'
